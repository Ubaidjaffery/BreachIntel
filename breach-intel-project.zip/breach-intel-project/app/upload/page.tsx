'use client';
import { useState, useRef, useEffect } from 'react';
import { Lock, Upload, CheckCircle, AlertCircle, X, FileSpreadsheet, Eye, EyeOff } from 'lucide-react';

type UploadResult = { success: boolean; message: string };

export default function UploadPage() {
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadMode, setUploadMode] = useState<'append' | 'replace'>('append');
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<UploadResult | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (sessionStorage.getItem('upload_authed') === '1') setAuthed(true);
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError('');
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (data.success) {
        sessionStorage.setItem('upload_authed', '1');
        setAuthed(true);
      } else {
        setAuthError(data.error || 'Incorrect password');
      }
    } catch {
      setAuthError('Network error — please try again');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleFileChange = (file: File | null) => {
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (!['xlsx', 'xls', 'csv'].includes(ext || '')) {
      setUploadResult({ success: false, message: 'Only .xlsx, .xls, or .csv files are supported' });
      return;
    }
    setUploadFile(file);
    setUploadResult(null);
  };

  const handleUpload = async () => {
    if (!uploadFile) return;
    setUploading(true);
    setUploadResult(null);
    try {
      const form = new FormData();
      form.append('file', uploadFile);
      form.append('mode', uploadMode);
      const res = await fetch('/api/upload', { method: 'POST', body: form });
      const data = await res.json();
      if (data.success) {
        setUploadResult({
          success: true,
          message: `${data.added.toLocaleString()} records ${uploadMode === 'replace' ? 'imported' : 'appended'}. Total in database: ${data.total.toLocaleString()}`,
        });
        setUploadFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } else {
        setUploadResult({ success: false, message: data.error || 'Upload failed' });
      }
    } catch {
      setUploadResult({ success: false, message: 'Network error — upload failed' });
    } finally {
      setUploading(false);
    }
  };

  const logout = () => {
    sessionStorage.removeItem('upload_authed');
    setAuthed(false);
    setPassword('');
    setUploadFile(null);
    setUploadResult(null);
  };

  // ── Password gate ──────────────────────────────────────────────────────────
  if (!authed) {
    return (
      <main style={{ minHeight: 'calc(100vh - 56px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px', background: 'linear-gradient(135deg, #08090f 0%, #0d0e1a 100%)' }}>
        <div style={{ width: '100%', maxWidth: 400 }}>
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{ width: 56, height: 56, background: 'rgba(229,57,92,0.1)', border: '1px solid rgba(229,57,92,0.25)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <Lock size={24} color="#e5395c" />
            </div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: 'var(--text-primary)', marginBottom: 6 }}>Admin Access</h1>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Enter the password to access the data import panel</p>
          </div>

          <form onSubmit={handleAuth} style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 12, padding: 24 }}>
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  className="intel-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setAuthError(''); }}
                  placeholder="Enter password"
                  autoFocus
                  style={{ width: '100%', height: 42, paddingRight: 44, fontSize: 14 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(v => !v)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', display: 'flex', padding: 0 }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {authError && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#ef4444', marginBottom: 14 }}>
                <AlertCircle size={13} />
                {authError}
              </div>
            )}

            <button
              type="submit"
              className="btn-accent"
              disabled={!password || authLoading}
              style={{ width: '100%', height: 42, fontSize: 13, fontWeight: 700, opacity: !password || authLoading ? 0.6 : 1, cursor: !password || authLoading ? 'not-allowed' : 'pointer' }}
            >
              {authLoading ? 'Verifying…' : 'Continue'}
            </button>
          </form>
        </div>
      </main>
    );
  }

  // ── Upload panel ───────────────────────────────────────────────────────────
  return (
    <main style={{ minHeight: 'calc(100vh - 56px)', padding: '40px 24px', background: 'linear-gradient(135deg, #08090f 0%, #0d0e1a 100%)' }}>
      <div style={{ maxWidth: 680, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 32 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: 'var(--text-primary)', marginBottom: 4 }}>Data Import</h1>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Upload an Excel or CSV file to add records to the database</p>
          </div>
          <button
            onClick={logout}
            style={{ height: 32, padding: '0 12px', background: 'transparent', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text-secondary)', cursor: 'pointer', fontSize: 11, fontFamily: 'var(--font-display)', display: 'flex', alignItems: 'center', gap: 5 }}
          >
            <Lock size={11} />
            Lock
          </button>
        </div>

        {/* Mode toggle */}
        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 12, padding: 20, marginBottom: 16 }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Import Mode</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {([
              { value: 'append', label: 'Append', desc: 'Add new rows to existing data without removing anything' },
              { value: 'replace', label: 'Replace', desc: 'Wipe all existing records and import only this file' },
            ] as const).map(({ value, label, desc }) => (
              <button
                key={value}
                onClick={() => setUploadMode(value)}
                style={{ padding: '12px 14px', borderRadius: 8, border: `1px solid ${uploadMode === value ? 'rgba(229,57,92,0.5)' : 'var(--border)'}`, background: uploadMode === value ? 'rgba(229,57,92,0.08)' : 'transparent', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s' }}
              >
                <div style={{ fontSize: 13, fontWeight: 700, color: uploadMode === value ? '#e5395c' : 'var(--text-primary)', marginBottom: 4, fontFamily: 'var(--font-display)' }}>{label}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', lineHeight: 1.4 }}>{desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Drop zone */}
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false); handleFileChange(e.dataTransfer.files[0] ?? null); }}
          onClick={() => fileInputRef.current?.click()}
          style={{ background: dragOver ? 'rgba(229,57,92,0.06)' : 'var(--bg-card)', border: `2px dashed ${dragOver ? 'rgba(229,57,92,0.5)' : uploadFile ? 'rgba(34,197,94,0.4)' : 'var(--border)'}`, borderRadius: 12, padding: '40px 24px', textAlign: 'center', cursor: 'pointer', transition: 'all 0.15s', marginBottom: 16 }}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            style={{ display: 'none' }}
            onChange={e => handleFileChange(e.target.files?.[0] ?? null)}
          />
          {uploadFile ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <FileSpreadsheet size={32} color="#22c55e" />
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{uploadFile.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{(uploadFile.size / 1024).toFixed(0)} KB — click to change</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <Upload size={32} color="rgba(240,240,248,0.2)" />
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-secondary)' }}>Drop file here or click to browse</div>
              <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>Supports .xlsx, .xls, .csv</div>
            </div>
          )}
        </div>

        {/* Upload button */}
        <button
          className="btn-accent"
          onClick={handleUpload}
          disabled={!uploadFile || uploading}
          style={{ width: '100%', height: 46, fontSize: 14, fontWeight: 700, opacity: !uploadFile || uploading ? 0.5 : 1, cursor: !uploadFile || uploading ? 'not-allowed' : 'pointer', borderRadius: 10, marginBottom: 16 }}
        >
          {uploading ? 'Uploading…' : `Upload & ${uploadMode === 'replace' ? 'Replace Database' : 'Append to Database'}`}
        </button>

        {/* Result */}
        {uploadResult && (
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '14px 16px', borderRadius: 10, background: uploadResult.success ? 'rgba(34,197,94,0.08)' : 'rgba(239,68,68,0.08)', border: `1px solid ${uploadResult.success ? 'rgba(34,197,94,0.25)' : 'rgba(239,68,68,0.25)'}` }}>
            {uploadResult.success ? <CheckCircle size={16} color="#22c55e" style={{ flexShrink: 0, marginTop: 1 }} /> : <AlertCircle size={16} color="#ef4444" style={{ flexShrink: 0, marginTop: 1 }} />}
            <span style={{ fontSize: 13, color: uploadResult.success ? '#22c55e' : '#ef4444', flex: 1 }}>{uploadResult.message}</span>
            <button onClick={() => setUploadResult(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', display: 'flex', padding: 0, flexShrink: 0 }}>
              <X size={14} />
            </button>
          </div>
        )}

        {/* Required columns */}
        <div style={{ marginTop: 24, padding: '14px 16px', background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)', borderRadius: 10 }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 10 }}>Required Column Headers</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {['Category', 'Breach Date', 'Victim Name', 'Victim Domain', 'Threat Actor', 'Country', 'Region', 'Industry'].map(col => (
              <span key={col} style={{ fontSize: 11, fontFamily: 'var(--font-mono)', background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)', borderRadius: 4, padding: '3px 8px', color: 'var(--text-secondary)' }}>
                {col}
              </span>
            ))}
          </div>
          <p style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 10 }}>
            Column names are case-insensitive. Date format: <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10 }}>MM/DD/YYYY HH:MM AM/PM</span>
          </p>
        </div>
      </div>
    </main>
  );
}
