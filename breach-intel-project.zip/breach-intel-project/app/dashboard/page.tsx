'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import type { StatsData } from '@/types/breach';

export default function DashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState<StatsData | null>(null);
  const [loading, setLoading] = useState(true);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const monthlyChartRef = useRef<HTMLCanvasElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const chartInstances = useRef<any[]>([]);


  useEffect(() => {
    fetch('/api/stats')
      .then(r => r.json())
      .then(d => { setStats(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!stats || !chartRef.current || !monthlyChartRef.current) return;

    // Destroy old charts
    chartInstances.current.forEach(c => c?.destroy?.());
    chartInstances.current = [];

    import('chart.js/auto').then(({ default: Chart }) => {
      // Category chart
      const catCtx = chartRef.current;
      if (catCtx) {
        const cats = Object.entries(stats.categories);
        const colors = ['#ef4444', '#3b82f6', '#f59e0b', '#22c55e', '#a855f7', '#14b8a6', '#f97316'];
        const c1 = new Chart(catCtx, {
          type: 'doughnut',
          data: {
            labels: cats.map(([k]) => k),
            datasets: [{
              data: cats.map(([, v]) => v),
              backgroundColor: colors,
              borderColor: '#111220',
              borderWidth: 2,
            }],
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
              legend: { position: 'right', labels: { color: '#9ca3af', font: { size: 11 }, padding: 12 } },
            },
          },
        });
        chartInstances.current.push(c1);
      }

      // Monthly chart
      const monthCtx = monthlyChartRef.current;
      if (monthCtx) {
        const monthEntries = Object.entries(stats.monthly).slice(-12);
        const c2 = new Chart(monthCtx, {
          type: 'bar',
          data: {
            labels: monthEntries.map(([k]) => k),
            datasets: [{
              label: 'Breaches',
              data: monthEntries.map(([, v]) => v),
              backgroundColor: 'rgba(229,57,92,0.7)',
              borderColor: '#e5395c',
              borderWidth: 1,
              borderRadius: 3,
            }],
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
              x: { ticks: { color: '#6b7280', font: { size: 10 } }, grid: { display: false } },
              y: { ticks: { color: '#6b7280', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
            },
          },
        });
        chartInstances.current.push(c2);
      }
    });

    return () => { chartInstances.current.forEach(c => c?.destroy?.()); };
  }, [stats]);

  if (loading) {
    return (
      <div style={{ padding: '32px 24px', maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14, marginBottom: 24 }}>
          {Array(5).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 90, borderRadius: 10 }} />)}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 16 }}>
          {Array(4).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 280, borderRadius: 10 }} />)}
        </div>
      </div>
    );
  }

  if (!stats) return null;

  const total = Object.values(stats.categories).reduce((a, b) => a + b, 0);
  const catColors: Record<string, string> = {
    DDoS: '#3b82f6', Leaks: '#f59e0b', 'Selling of data': '#22c55e',
    Ransomware: '#ef4444', Defacement: '#a855f7', 'Underground chatter': '#14b8a6', 'Cyber Attack': '#f97316',
  };

  const topActors = Object.entries(stats.topActors).slice(0, 12);
  const maxActor = topActors[0]?.[1] || 1;
  const topIndustries = Object.entries(stats.topIndustries).filter(([k]) => k !== 'Unknown').slice(0, 10);
  const maxIndustry = topIndustries[0]?.[1] || 1;
  const topCountries = Object.entries(stats.topCountries).filter(([k]) => k !== 'Unknown').slice(0, 10);
  const maxCountry = topCountries[0]?.[1] || 1;

  return (
    <main style={{ minHeight: 'calc(100vh - 56px)', padding: '0 0 40px' }}>
      {/* Header */}
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)', padding: '20px 24px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: 'var(--text-primary)', marginBottom: 4 }}>Threat Intelligence Dashboard</h1>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Analytics across {total.toLocaleString()} breach records</p>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '24px' }}>
        {/* Metric cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginBottom: 24 }}>
          {Object.entries(stats.categories).map(([cat, count]) => {
            const col = catColors[cat] || '#6b7280';
            return (
              <div
                key={cat}
                className="stat-card"
                style={{ cursor: 'pointer', transition: 'border-color 0.15s' }}
                onClick={() => router.push(`/search?category=${encodeURIComponent(cat)}`)}
                onMouseEnter={e => (e.currentTarget.style.borderColor = col)}
                onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border)')}
              >
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.5px' }}>{cat}</div>
                <div style={{ fontSize: 26, fontWeight: 800, color: col, fontFamily: 'var(--font-display)', marginBottom: 6 }}>{count.toLocaleString()}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{Math.round((count / total) * 100)}% of total</div>
              </div>
            );
          })}
        </div>

        {/* Charts row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16, marginBottom: 16 }}>
          {/* Category donut */}
          <div className="stat-card">
            <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 16 }}>Attack Category Distribution</h3>
            <div style={{ position: 'relative', height: 240 }}>
              <canvas ref={chartRef} />
            </div>
          </div>

          {/* Monthly trend */}
          <div className="stat-card" style={{ gridColumn: 'span 2' }}>
            <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 16 }}>Monthly Breach Volume (Last 12 months)</h3>
            <div style={{ position: 'relative', height: 200 }}>
              <canvas ref={monthlyChartRef} />
            </div>
          </div>
        </div>

        {/* Bar charts */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 16 }}>
          {/* Top actors */}
          <div className="stat-card">
            <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 16 }}>Most Active Threat Actors</h3>
            {topActors.map(([name, count], i) => (
              <div
                key={name}
                style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, cursor: 'pointer' }}
                onClick={() => router.push(`/search?actor=${encodeURIComponent(name)}`)}
              >
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)', width: 18, textAlign: 'center', flexShrink: 0 }}>#{i + 1}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 180 }}>{name}</span>
                    <span style={{ fontSize: 12, color: '#e5395c', fontWeight: 600, flexShrink: 0 }}>{count.toLocaleString()}</span>
                  </div>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2 }}>
                    <div style={{ height: '100%', width: `${Math.round((count / maxActor) * 100)}%`, background: '#e5395c', borderRadius: 2 }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Top industries */}
          <div className="stat-card">
            <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 16 }}>Top Targeted Industries</h3>
            {topIndustries.map(([name, count]) => (
              <div
                key={name}
                style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, cursor: 'pointer' }}
                onClick={() => router.push(`/search?industry=${encodeURIComponent(name)}`)}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 200 }}>{name}</span>
                    <span style={{ fontSize: 12, color: '#3b82f6', fontWeight: 600, flexShrink: 0 }}>{count.toLocaleString()}</span>
                  </div>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2 }}>
                    <div style={{ height: '100%', width: `${Math.round((count / maxIndustry) * 100)}%`, background: '#3b82f6', borderRadius: 2 }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Top countries */}
          <div className="stat-card">
            <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 16 }}>Top Targeted Countries</h3>
            {topCountries.map(([name, count]) => (
              <div
                key={name}
                style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, cursor: 'pointer' }}
                onClick={() => router.push(`/search?country=${encodeURIComponent(name)}`)}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 12, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 200 }}>
                      {name.length > 35 ? name.slice(0, 35) + '…' : name}
                    </span>
                    <span style={{ fontSize: 12, color: '#22c55e', fontWeight: 600, flexShrink: 0 }}>{count.toLocaleString()}</span>
                  </div>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2 }}>
                    <div style={{ height: '100%', width: `${Math.round((count / maxCountry) * 100)}%`, background: '#22c55e', borderRadius: 2 }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Regions */}
          <div className="stat-card">
            <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 16 }}>Breach by Region</h3>
            {Object.entries(stats.topRegions).filter(([k]) => k !== 'Unknown').slice(0, 10).map(([region, count]) => {
              const maxR = Object.entries(stats.topRegions).filter(([k]) => k !== 'Unknown')[0]?.[1] || 1;
              return (
                <div key={region} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, cursor: 'pointer' }} onClick={() => router.push(`/search?region=${encodeURIComponent(region)}`)}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ fontSize: 12, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 200 }}>{region}</span>
                      <span style={{ fontSize: 12, color: '#f59e0b', fontWeight: 600, flexShrink: 0 }}>{count.toLocaleString()}</span>
                    </div>
                    <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2 }}>
                      <div style={{ height: '100%', width: `${Math.round((count / maxR) * 100)}%`, background: '#f59e0b', borderRadius: 2 }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </main>
  );
}
