'use client';
import { useState, useEffect, useCallback, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Search, SlidersHorizontal, X, ChevronLeft, ChevronRight } from 'lucide-react';
import type { BreachRecord, SearchResult, SortOption } from '@/types/breach';
import BreachModal from '@/components/BreachModal';
import BreachCard from '@/components/BreachCard';

function SearchContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [country, setCountry] = useState(searchParams.get('country') || '');
  const [industry, setIndustry] = useState(searchParams.get('industry') || '');
  const [actor, setActor] = useState(searchParams.get('actor') || '');
  const [sort, setSort] = useState<SortOption>((searchParams.get('sort') as SortOption) || 'date-desc');
  const [page, setPage] = useState(1);

  const [results, setResults] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<BreachRecord | null>(null);
  const [filterOptions, setFilterOptions] = useState<{ categories: string[]; countries: string[]; industries: string[]; actors: string[] }>({
    categories: [], countries: [], industries: [], actors: [],
  });
  const [showFilters, setShowFilters] = useState(false);

  // Load filter options once
  useEffect(() => {
    fetch('/api/filters')
      .then(r => r.json())
      .then(setFilterOptions)
      .catch(console.error);
  }, []);

  const doSearch = useCallback(async (resetPage = true) => {
    const pg = resetPage ? 1 : page;
    if (resetPage) setPage(1);
    setLoading(true);

    const params = new URLSearchParams();
    if (query) params.set('q', query);
    if (category) params.set('category', category);
    if (country) params.set('country', country);
    if (industry) params.set('industry', industry);
    if (actor) params.set('actor', actor);
    params.set('sort', sort);
    params.set('page', String(pg));
    params.set('perPage', '20');

    try {
      const r = await fetch(`/api/search?${params.toString()}`);
      const d = await r.json();
      setResults(d);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [query, category, country, industry, actor, sort, page]);

  // Initial search from URL params
  useEffect(() => {
    doSearch(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-search when filters change
  useEffect(() => {
    doSearch(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, country, industry, actor, sort]);

  // Re-search when page changes
  useEffect(() => {
    if (page > 1) doSearch(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const clearFilters = () => {
    setCategory(''); setCountry(''); setIndustry(''); setActor('');
    setQuery(''); setSort('date-desc'); setPage(1);
  };

  const hasFilters = category || country || industry || actor || query;

  return (
    <main style={{ minHeight: 'calc(100vh - 56px)' }}>
      {/* Search Header */}
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)', padding: '14px 24px', position: 'sticky', top: 56, zIndex: 100 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 240, position: 'relative' }}>
            <Search size={15} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
            <input
              className="intel-input"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && doSearch(true)}
              placeholder="Search breaches, domains, actors..."
              style={{ width: '100%', height: 38, paddingLeft: 36, fontSize: 13 }}
            />
          </div>
          <select
            className="intel-select"
            value={sort}
            onChange={e => setSort(e.target.value as SortOption)}
            style={{ height: 38, padding: '0 28px 0 10px', minWidth: 140 }}
          >
            <option value="date-desc">Latest first</option>
            <option value="date-asc">Oldest first</option>
            <option value="victim">Victim name</option>
            <option value="actor">Threat actor</option>
            <option value="country">Country</option>
          </select>
          <button
            onClick={() => setShowFilters(!showFilters)}
            style={{ height: 38, padding: '0 14px', background: showFilters ? 'rgba(229,57,92,0.1)' : 'transparent', border: `1px solid ${showFilters ? 'rgba(229,57,92,0.3)' : 'var(--border)'}`, borderRadius: 6, color: showFilters ? '#e5395c' : 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontFamily: 'var(--font-display)', transition: 'all 0.15s' }}
          >
            <SlidersHorizontal size={14} />
            Filters
          </button>
          <button
            className="btn-accent"
            onClick={() => doSearch(true)}
            style={{ height: 38, padding: '0 20px', fontSize: 13 }}
          >
            Search
          </button>
        </div>

        {/* Filter Bar */}
        {showFilters && (
          <div style={{ maxWidth: 1280, margin: '12px auto 0', display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <select className="intel-select" value={category} onChange={e => setCategory(e.target.value)} style={{ height: 32, padding: '0 26px 0 8px', fontSize: 11 }}>
              <option value="">All categories</option>
              {filterOptions.categories.map(c => <option key={c}>{c}</option>)}
            </select>
            <select className="intel-select" value={country} onChange={e => setCountry(e.target.value)} style={{ height: 32, padding: '0 26px 0 8px', fontSize: 11 }}>
              <option value="">All countries</option>
              {filterOptions.countries.map(c => <option key={c}>{c}</option>)}
            </select>
            <select className="intel-select" value={industry} onChange={e => setIndustry(e.target.value)} style={{ height: 32, padding: '0 26px 0 8px', fontSize: 11 }}>
              <option value="">All industries</option>
              {filterOptions.industries.map(i => <option key={i}>{i}</option>)}
            </select>
            <select className="intel-select" value={actor} onChange={e => setActor(e.target.value)} style={{ height: 32, padding: '0 26px 0 8px', fontSize: 11 }}>
              <option value="">All threat actors</option>
              {filterOptions.actors.slice(0, 200).map(a => <option key={a}>{a}</option>)}
            </select>
            {hasFilters && (
              <button
                onClick={clearFilters}
                style={{ height: 32, padding: '0 10px', background: 'transparent', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text-secondary)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontFamily: 'var(--font-display)' }}
              >
                <X size={11} /> Clear
              </button>
            )}
          </div>
        )}
      </div>

      {/* Results */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '20px 24px' }}>
        {/* Meta */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
            {loading ? (
              <span>Searching...</span>
            ) : results ? (
              <span>
                Showing <strong style={{ color: 'var(--text-primary)' }}>{Math.min(20, results.total - (page-1)*20)}</strong> of{' '}
                <strong style={{ color: '#e5395c' }}>{results.total.toLocaleString()}</strong> results
                {query && <span> for "<strong style={{ color: 'var(--text-primary)' }}>{query}</strong>"</span>}
              </span>
            ) : null}
          </div>
          {results && results.total > 0 && (
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>
              Page {page} of {results.totalPages}
            </div>
          )}
        </div>

        {/* Loading skeletons */}
        {loading && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {Array(8).fill(0).map((_, i) => (
              <div key={i} className="skeleton" style={{ height: 90, borderRadius: 8 }} />
            ))}
          </div>
        )}

        {/* Empty state */}
        {!loading && results && results.total === 0 && (
          <div style={{ textAlign: 'center', padding: '64px 24px' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, marginBottom: 8 }}>No results found</div>
            <div style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 20 }}>Try a different search term or clear the filters</div>
            <button className="btn-accent" onClick={clearFilters} style={{ height: 38, padding: '0 20px', fontSize: 13 }}>Clear filters</button>
          </div>
        )}

        {/* Results list */}
        {!loading && results && results.records.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {results.records.map(r => (
              <BreachCard key={r.id} record={r} onClick={setSelectedRecord} />
            ))}
          </div>
        )}

        {/* Pagination */}
        {results && results.totalPages > 1 && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 24 }}>
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              style={{ width: 32, height: 32, border: '1px solid var(--border)', borderRadius: 6, background: 'transparent', color: page === 1 ? 'var(--text-tertiary)' : 'var(--text-secondary)', cursor: page === 1 ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            >
              <ChevronLeft size={14} />
            </button>

            {Array.from({ length: Math.min(7, results.totalPages) }, (_, i) => {
              let pg: number;
              if (results.totalPages <= 7) pg = i + 1;
              else if (page <= 4) pg = i + 1;
              else if (page >= results.totalPages - 3) pg = results.totalPages - 6 + i;
              else pg = page - 3 + i;
              return (
                <button
                  key={pg}
                  onClick={() => setPage(pg)}
                  style={{ minWidth: 32, height: 32, border: '1px solid var(--border)', borderRadius: 6, background: pg === page ? '#e5395c' : 'transparent', color: pg === page ? '#fff' : 'var(--text-secondary)', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font-display)', transition: 'all 0.15s' }}
                >
                  {pg}
                </button>
              );
            })}

            {results.totalPages > 7 && page < results.totalPages - 3 && (
              <span style={{ color: 'var(--text-tertiary)', fontSize: 13 }}>... {results.totalPages}</span>
            )}

            <button
              onClick={() => setPage(p => Math.min(results.totalPages, p + 1))}
              disabled={page === results.totalPages}
              style={{ width: 32, height: 32, border: '1px solid var(--border)', borderRadius: 6, background: 'transparent', color: page === results.totalPages ? 'var(--text-tertiary)' : 'var(--text-secondary)', cursor: page === results.totalPages ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            >
              <ChevronRight size={14} />
            </button>
          </div>
        )}
      </div>

      {/* Modal */}
      {selectedRecord && (
        <BreachModal
          record={selectedRecord}
          onClose={() => setSelectedRecord(null)}
          onRelatedClick={r => setSelectedRecord(r)}
        />
      )}
    </main>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div style={{ padding: 24, color: 'var(--text-secondary)' }}>Loading...</div>}>
      <SearchContent />
    </Suspense>
  );
}
