'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Shield, Zap, Globe, TrendingUp, AlertTriangle } from 'lucide-react';
import type { BreachRecord, StatsData } from '@/types/breach';
import BreachModal from '@/components/BreachModal';

export default function HomePage() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [recentBreaches, setRecentBreaches] = useState<BreachRecord[]>([]);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [selectedRecord, setSelectedRecord] = useState<BreachRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load stats
    fetch('/api/stats')
      .then(r => r.json())
      .then(setStats)
      .catch(console.error);

    // Load recent breaches
    fetch('/api/search?sort=date-desc&perPage=9')
      .then(r => r.json())
      .then(d => {
        setRecentBreaches(d.records || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleAutocomplete = useCallback(async (val: string) => {
    if (!val || val.length < 2) { setSuggestions([]); return; }
    try {
      const r = await fetch(`/api/filters?autocomplete=${encodeURIComponent(val)}`);
      const d = await r.json();
      setSuggestions(d.suggestions || []);
    } catch { setSuggestions([]); }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => handleAutocomplete(query), 200);
    return () => clearTimeout(t);
  }, [query, handleAutocomplete]);

  const doSearch = (q: string) => {
    if (!q.trim()) return;
    router.push(`/search?q=${encodeURIComponent(q.trim())}`);
  };

  const getCategoryBadge = (cat: string) => {
    const map: Record<string, string> = {
      Ransomware: 'badge-ransomware',
      DDoS: 'badge-ddos',
      Leaks: 'badge-leaks',
      'Selling of data': 'badge-selling',
      Defacement: 'badge-defacement',
      'Underground chatter': 'badge-underground',
      'Cyber Attack': 'badge-cyber',
    };
    return map[cat] || 'badge-unknown';
  };

  const formatTimeAgo = (iso: string) => {
    if (!iso) return '';
    const diff = Date.now() - new Date(iso).getTime();
    const days = Math.floor(diff / 86400000);
    if (days < 1) return 'Today';
    if (days < 7) return `${days}d ago`;
    if (days < 30) return `${Math.floor(days / 7)}w ago`;
    if (days < 365) return `${Math.floor(days / 30)}mo ago`;
    return `${Math.floor(days / 365)}y ago`;
  };

  const TRENDING_SEARCHES = ['NoName057(16)', 'Ransomware', 'Healthcare', 'Government', 'India', 'Qilin'];
  const TOP_ACTORS = ['NoName057(16)', 'LOCKBIT', 'PLAY', 'QILIN', 'AKIRA', 'DARK STORM TEAM', 'KEYMOUS+', 'HEZI RASH', 'RIPPERSEC', 'INC RANSOM'];

  return (
    <main>
      {/* Hero */}
      <div
        style={{
          background: 'linear-gradient(135deg, #08090f 0%, #0d0e1a 50%, #0f1120 100%)',
          padding: '80px 24px 64px',
          textAlign: 'center',
          position: 'relative',
          overflow: 'hidden',
          minHeight: 380,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {/* Grid BG */}
        <div className="grid-bg" style={{ position: 'absolute', inset: 0, opacity: 0.6 }} />

        {/* Glow orb */}
        <div style={{ position: 'absolute', top: '30%', left: '50%', transform: 'translate(-50%,-50%)', width: 500, height: 300, background: 'radial-gradient(ellipse, rgba(229,57,92,0.08) 0%, transparent 70%)', pointerEvents: 'none' }} />

        <div style={{ position: 'relative', maxWidth: 720, width: '100%' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(229,57,92,0.1)', border: '1px solid rgba(229,57,92,0.25)', color: '#e5395c', fontSize: 11, padding: '5px 14px', borderRadius: 20, marginBottom: 24, fontWeight: 600, letterSpacing: '0.5px' }}>
            <span className="pulse-dot" style={{ width: 7, height: 7, borderRadius: '50%', background: '#e5395c', display: 'inline-block' }} />
            LIVE INTELLIGENCE — {stats?.total?.toLocaleString() || '50,000+'} BREACH RECORDS INDEXED
          </div>

          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(28px, 5vw, 52px)', color: '#f0f0f8', marginBottom: 12, lineHeight: 1.1, letterSpacing: '-1px' }}>
            Have you been <span style={{ color: '#e5395c' }}>breached</span>?
          </h1>

          <p style={{ color: 'rgba(240,240,248,0.5)', fontSize: 15, marginBottom: 36, maxWidth: 500, margin: '0 auto 36px' }}>
            Search domains, organizations &amp; threat actors across the world's largest open breach dataset
          </p>

          {/* Search bar */}
          <div style={{ position: 'relative', maxWidth: 640, margin: '0 auto' }}>
            <div style={{ position: 'relative' }}>
              <Search size={18} style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', color: 'rgba(240,240,248,0.35)' }} />
              <input
                className="intel-input"
                value={query}
                onChange={e => { setQuery(e.target.value); setShowSuggestions(true); }}
                onKeyDown={e => { if (e.key === 'Enter') doSearch(query); if (e.key === 'Escape') setShowSuggestions(false); }}
                onFocus={() => setShowSuggestions(true)}
                placeholder="Search domain, victim, threat actor..."
                style={{ width: '100%', height: 54, paddingLeft: 48, paddingRight: 120, fontSize: 15, borderRadius: 10, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.15)' }}
                autoComplete="off"
              />
              <button
                className="btn-accent"
                onClick={() => doSearch(query)}
                style={{ position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)', height: 40, padding: '0 20px', borderRadius: 7, fontWeight: 700, fontSize: 13 }}
              >
                Search
              </button>
            </div>

            {/* Autocomplete */}
            {showSuggestions && suggestions.length > 0 && (
              <div style={{ position: 'absolute', top: 58, left: 0, right: 0, background: '#0d0e1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, overflow: 'hidden', zIndex: 300, boxShadow: '0 16px 40px rgba(0,0,0,0.6)' }}>
                {suggestions.map((s, i) => (
                  <div
                    key={i}
                    onClick={() => { setQuery(s); setShowSuggestions(false); doSearch(s); }}
                    style={{ padding: '10px 16px', fontSize: 13, color: 'rgba(240,240,248,0.8)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, transition: 'background 0.1s' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'rgba(229,57,92,0.08)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <Search size={12} style={{ color: 'var(--text-tertiary)', flexShrink: 0 }} />
                    {s}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Trending */}
          <div style={{ display: 'flex', gap: 8, marginTop: 20, flexWrap: 'wrap', justifyContent: 'center' }}>
            {TRENDING_SEARCHES.map(t => (
              <button
                key={t}
                onClick={() => doSearch(t)}
                style={{ background: 'rgba(255,255,255,0.07)', color: 'rgba(240,240,248,0.6)', fontSize: 11, padding: '4px 12px', borderRadius: 20, border: '1px solid rgba(255,255,255,0.12)', cursor: 'pointer', transition: 'all 0.15s', fontFamily: 'var(--font-display)' }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(229,57,92,0.12)'; (e.currentTarget as HTMLButtonElement).style.color = '#e5395c'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(229,57,92,0.3)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.07)'; (e.currentTarget as HTMLButtonElement).style.color = 'rgba(240,240,248,0.6)'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(255,255,255,0.12)'; }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)', padding: '20px 24px', display: 'flex', gap: 0, justifyContent: 'center', flexWrap: 'wrap' }}>
        {[
          { icon: <Shield size={16} />, num: stats?.total?.toLocaleString() || '50,000', label: 'Total Records' },
          { icon: <AlertTriangle size={16} />, num: stats?.categories?.['DDoS']?.toLocaleString() || '15,113', label: 'DDoS Attacks' },
          { icon: <Zap size={16} />, num: stats?.categories?.['Ransomware']?.toLocaleString() || '7,531', label: 'Ransomware Incidents' },
          { icon: <TrendingUp size={16} />, num: Object.keys(stats?.topActors || {}).length || '450+', label: 'Threat Actors' },
          { icon: <Globe size={16} />, num: Object.keys(stats?.topCountries || {}).length || '80+', label: 'Countries Affected' },
        ].map(({ icon, num, label }, i) => (
          <div key={i} style={{ textAlign: 'center', padding: '8px 28px', borderRight: i < 4 ? '1px solid var(--border)' : 'none' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, color: '#e5395c', marginBottom: 4 }}>
              {icon}
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: '#e5395c' }}>{num}</span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', letterSpacing: '0.5px', fontWeight: 500 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Ticker */}
      <div style={{ background: 'rgba(229,57,92,0.05)', borderBottom: '1px solid rgba(229,57,92,0.1)', padding: '8px 0', overflow: 'hidden', fontSize: 11, color: 'rgba(229,57,92,0.7)' }}>
        <div className="ticker-inner">
          {Array(2).fill(TOP_ACTORS).flat().map((a, i) => (
            <span key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 5, height: 5, borderRadius: '50%', background: '#e5395c', display: 'inline-block', flexShrink: 0 }} />
              {a}
            </span>
          ))}
        </div>
      </div>

      {/* Recent Breaches */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17, color: 'var(--text-primary)', marginBottom: 2 }}>Recent breach activity</h2>
            <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Latest claims from threat actors — updated continuously</p>
          </div>
          <button
            onClick={() => router.push('/search')}
            className="btn-accent"
            style={{ height: 36, padding: '0 16px', fontSize: 12, borderRadius: 6 }}
          >
            View all →
          </button>
        </div>

        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
            {Array(9).fill(0).map((_, i) => (
              <div key={i} className="skeleton" style={{ height: 110, borderRadius: 8 }} />
            ))}
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
            {recentBreaches.map(r => (
              <div
                key={r.id}
                className="breach-card"
                onClick={() => setSelectedRecord(r)}
                style={{ padding: '14px 16px' }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10, gap: 10 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 2 }}>
                      {r['Victim Name'] || 'Unknown Victim'}
                    </div>
                    {r['Victim Domain'] && (
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#e5395c', opacity: 0.85, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {r['Victim Domain']}
                      </div>
                    )}
                  </div>
                  <span className={getCategoryBadge(r.Category)} style={{ fontSize: 10, padding: '2px 8px', borderRadius: 4, fontWeight: 600, flexShrink: 0 }}>
                    {r.Category}
                  </span>
                </div>
                <div style={{ display: 'flex', gap: 10, fontSize: 12, color: 'var(--text-secondary)', flexWrap: 'wrap' }}>
                  {r['Threat Actor'] && (
                    <span style={{ color: 'var(--text-primary)', fontWeight: 500, fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 180 }}>
                      ⚡ {r['Threat Actor']}
                    </span>
                  )}
                  {r.Country && <span style={{ fontSize: 11 }}>📍 {r.Country.length > 20 ? r.Country.slice(0,20)+'…' : r.Country}</span>}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
                  <span>{r['Breach Date']?.split(' ')[0]}</span>
                  <span>{formatTimeAgo(r.breach_date_iso)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Browse by Actor */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px 32px' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17, color: 'var(--text-primary)', marginBottom: 16 }}>Browse by threat actor</h2>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {TOP_ACTORS.map(a => (
            <button
              key={a}
              onClick={() => doSearch(a)}
              style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontSize: 12, padding: '6px 14px', borderRadius: 20, cursor: 'pointer', transition: 'all 0.15s', fontFamily: 'var(--font-display)' }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(229,57,92,0.4)'; (e.currentTarget as HTMLButtonElement).style.color = '#e5395c'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-primary)'; }}
            >
              {a}
            </button>
          ))}
        </div>
      </div>

      {/* Stats section */}
      {stats && (
        <div style={{ background: 'var(--bg-secondary)', borderTop: '1px solid var(--border)', padding: '32px 24px' }}>
          <div style={{ maxWidth: 1280, margin: '0 auto' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17, color: 'var(--text-primary)', marginBottom: 24, textAlign: 'center' }}>Intelligence Overview</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
              {Object.entries(stats.categories).map(([cat, count]) => {
                const colors: Record<string, string> = { DDoS: '#3b82f6', Leaks: '#f59e0b', 'Selling of data': '#22c55e', Ransomware: '#ef4444', Defacement: '#a855f7', 'Underground chatter': '#14b8a6', 'Cyber Attack': '#f97316' };
                const col = colors[cat] || '#6b7280';
                const total = Object.values(stats.categories).reduce((a, b) => a + b, 0);
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={cat} className="stat-card" style={{ cursor: 'pointer' }} onClick={() => router.push(`/search?category=${encodeURIComponent(cat)}`)}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{cat}</span>
                      <span style={{ fontSize: 11, color: col, fontWeight: 700 }}>{pct}%</span>
                    </div>
                    <div style={{ fontSize: 24, fontWeight: 800, color: col, marginBottom: 8, fontFamily: 'var(--font-display)' }}>{count.toLocaleString()}</div>
                    <div style={{ height: 4, background: 'var(--border)', borderRadius: 2 }}>
                      <div style={{ height: '100%', width: `${pct}%`, background: col, borderRadius: 2, transition: 'width 0.6s ease' }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Modal */}
      {selectedRecord && (
        <BreachModal
          record={selectedRecord}
          onClose={() => setSelectedRecord(null)}
          onRelatedClick={r => setSelectedRecord(r)}
        />
      )}

      {/* Overlay click dismiss */}
      {showSuggestions && (
        <div
          style={{ position: 'fixed', inset: 0, zIndex: 200 }}
          onClick={() => setShowSuggestions(false)}
        />
      )}
    </main>
  );
}
