'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Search } from 'lucide-react';

interface ThreatActor {
  name: string;
  count: number;
  categories: string[];
  countries: string[];
}

export default function ThreatActorsPage() {
  const router = useRouter();
  const [actors, setActors] = useState<ThreatActor[]>([]);
  const [filtered, setFiltered] = useState<ThreatActor[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const PER_PAGE = 30;

  useEffect(() => {
    fetch('/api/threat-actors')
      .then(r => r.json())
      .then(d => { setActors(d.actors || []); setFiltered(d.actors || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!query.trim()) { setFiltered(actors); return; }
    const q = query.toLowerCase();
    setFiltered(actors.filter(a => a.name.toLowerCase().includes(q)));
    setPage(1);
  }, [query, actors]);

  const getCategoryBadge = (cat: string) => {
    const map: Record<string, string> = {
      Ransomware: 'badge-ransomware', DDoS: 'badge-ddos', Leaks: 'badge-leaks',
      'Selling of data': 'badge-selling', Defacement: 'badge-defacement',
      'Underground chatter': 'badge-underground', 'Cyber Attack': 'badge-cyber',
    };
    return map[cat] || 'badge-unknown';
  };

  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const totalPages = Math.ceil(filtered.length / PER_PAGE);

  return (
    <main style={{ minHeight: 'calc(100vh - 56px)' }}>
      <div style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)', padding: '20px 24px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: 'var(--text-primary)', marginBottom: 4 }}>Threat Actors</h1>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 16 }}>
            {actors.length} unique threat actors tracked across {actors.reduce((s, a) => s + a.count, 0).toLocaleString()} incidents
          </p>
          <div style={{ position: 'relative', maxWidth: 400 }}>
            <Search size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
            <input
              className="intel-input"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search threat actors..."
              style={{ width: '100%', height: 36, paddingLeft: 32, fontSize: 13 }}
            />
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '24px' }}>
        {loading && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
            {Array(12).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 120, borderRadius: 8 }} />)}
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '64px 24px', color: 'var(--text-secondary)' }}>
            No threat actors found for "{query}"
          </div>
        )}

        {!loading && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
            {paged.map((actor, i) => (
              <div
                key={actor.name}
                className="breach-card"
                style={{ padding: '16px', cursor: 'pointer' }}
                onClick={() => router.push(`/search?actor=${encodeURIComponent(actor.name)}`)}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 2 }}>
                      {actor.name}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>
                      Rank #{(page - 1) * PER_PAGE + i + 1}
                    </div>
                  </div>
                  <div style={{ fontSize: 18, fontWeight: 800, color: '#e5395c', fontFamily: 'var(--font-display)', flexShrink: 0 }}>
                    {actor.count.toLocaleString()}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
                  {actor.categories.slice(0, 3).map(cat => (
                    <span key={cat} className={getCategoryBadge(cat)} style={{ fontSize: 10, padding: '2px 6px', borderRadius: 3, fontWeight: 600 }}>
                      {cat}
                    </span>
                  ))}
                </div>

                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  📍 {actor.countries.slice(0, 3).join(', ')}
                  {actor.countries.length > 3 && ` +${actor.countries.length - 3} more`}
                </div>

                <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--border)' }}>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2 }}>
                    <div style={{ height: '100%', width: `${Math.min(100, Math.round((actor.count / (actors[0]?.count || 1)) * 100))}%`, background: '#e5395c', borderRadius: 2 }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 24 }}>
            {Array.from({ length: Math.min(10, totalPages) }, (_, i) => i + 1).map(pg => (
              <button
                key={pg}
                onClick={() => setPage(pg)}
                style={{ minWidth: 32, height: 32, border: '1px solid var(--border)', borderRadius: 6, background: pg === page ? '#e5395c' : 'transparent', color: pg === page ? '#fff' : 'var(--text-secondary)', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font-display)' }}
              >
                {pg}
              </button>
            ))}
            {totalPages > 10 && <span style={{ color: 'var(--text-tertiary)', fontSize: 13 }}>...{totalPages}</span>}
          </div>
        )}
      </div>
    </main>
  );
}
