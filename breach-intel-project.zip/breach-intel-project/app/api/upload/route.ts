import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import path from 'path';
import fs from 'fs';
import { clearCache } from '@/lib/dataStore';

export const dynamic = 'force-dynamic';

const COLUMN_MAP: Record<string, string> = {
  'category': 'Category',
  'breach date': 'Breach Date',
  'victim name': 'Victim Name',
  'victim domain': 'Victim Domain',
  'threat actor': 'Threat Actor',
  'country': 'Country',
  'region': 'Region',
  'industry': 'Industry',
};

function parseDate(val: unknown): string {
  if (!val) return '';
  if (val instanceof Date) return isNaN(val.getTime()) ? '' : val.toISOString();
  if (typeof val === 'string' && val.trim()) {
    const direct = new Date(val);
    if (!isNaN(direct.getTime())) return direct.toISOString();
    const m = val.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})\s*(AM|PM)/i);
    if (m) {
      let h = parseInt(m[4]);
      const min = parseInt(m[5]);
      if (m[6].toUpperCase() === 'PM' && h !== 12) h += 12;
      if (m[6].toUpperCase() === 'AM' && h === 12) h = 0;
      return new Date(parseInt(m[3]), parseInt(m[1]) - 1, parseInt(m[2]), h, min).toISOString();
    }
  }
  return '';
}

function computeStats(records: Record<string, unknown>[]) {
  const categories: Record<string, number> = {};
  const topActors: Record<string, number> = {};
  const topCountries: Record<string, number> = {};
  const topIndustries: Record<string, number> = {};
  const topRegions: Record<string, number> = {};
  const monthly: Record<string, number> = {};

  for (const r of records) {
    const cat = (r.Category as string) || '';
    if (cat) categories[cat] = (categories[cat] || 0) + 1;

    const actor = (r['Threat Actor'] as string) || '';
    if (actor) topActors[actor] = (topActors[actor] || 0) + 1;

    const rawCountry = (r.Country as string) || '';
    const countries = rawCountry ? rawCountry.split(',').map(s => s.trim()).filter(Boolean) : ['Unknown'];
    for (const c of countries) topCountries[c] = (topCountries[c] || 0) + 1;

    const rawInd = (r.Industry as string) || '';
    const inds = rawInd ? rawInd.split(',').map(s => s.trim()).filter(Boolean) : ['Unknown'];
    for (const ind of inds) topIndustries[ind] = (topIndustries[ind] || 0) + 1;

    const reg = (r.Region as string) || 'Unknown';
    topRegions[reg] = (topRegions[reg] || 0) + 1;

    const iso = r.breach_date_iso as string;
    if (iso && iso.length >= 7) {
      const month = iso.slice(0, 7);
      monthly[month] = (monthly[month] || 0) + 1;
    }
  }

  const topN = (obj: Record<string, number>, n: number) =>
    Object.fromEntries(Object.entries(obj).sort(([, a], [, b]) => b - a).slice(0, n));

  const sortedMonthly = Object.fromEntries(
    Object.entries(monthly).sort(([a], [b]) => a.localeCompare(b)).slice(-24)
  );

  return {
    total: records.length,
    categories,
    topIndustries: topN(topIndustries, 20),
    topActors: topN(topActors, 50),
    topCountries: topN(topCountries, 30),
    topRegions: topN(topRegions, 15),
    monthly: sortedMonthly,
  };
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const mode = (formData.get('mode') as string) || 'append';

    if (!file) return NextResponse.json({ error: 'No file provided' }, { status: 400 });

    const ext = file.name.split('.').pop()?.toLowerCase();
    if (!['xlsx', 'xls', 'csv'].includes(ext || '')) {
      return NextResponse.json({ error: 'Only .xlsx, .xls, or .csv files are supported' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const workbook = XLSX.read(buffer, { type: 'buffer', cellDates: true });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

    if (!rows.length) return NextResponse.json({ error: 'File is empty or has no rows' }, { status: 400 });

    const dataPath = path.join(process.cwd(), 'data', 'tac_data.json');
    let existing: Record<string, unknown>[] = [];
    if (mode === 'append' && fs.existsSync(dataPath)) {
      existing = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
    }

    const startId = existing.length > 0
      ? Math.max(...existing.map(r => (r.id as number) || 0)) + 1
      : 1;

    const newRecords = rows.map((row, i) => {
      const normalized: Record<string, string> = {};
      for (const [k, v] of Object.entries(row)) {
        const mapped = COLUMN_MAP[k.toLowerCase().trim()];
        if (mapped) normalized[mapped] = String(v).replace(/\xa0/g, ' ').trim();
      }

      const rawDate = row[
        Object.keys(row).find(k => k.toLowerCase().includes('breach date') || k.toLowerCase() === 'breach_date') ?? ''
      ] ?? normalized['Breach Date'] ?? '';

      return {
        id: startId + i,
        Category: normalized['Category'] || '',
        'Breach Date': normalized['Breach Date'] || '',
        'Victim Name': normalized['Victim Name'] || '',
        'Victim Domain': normalized['Victim Domain'] || '',
        'Threat Actor': normalized['Threat Actor'] || '',
        Country: normalized['Country'] || '',
        Region: normalized['Region'] || '',
        Industry: normalized['Industry'] || '',
        source: 'upload',
        breach_date_iso: parseDate(rawDate),
      };
    });

    const allRecords = [...existing, ...newRecords];

    fs.writeFileSync(dataPath, JSON.stringify(allRecords));
    fs.writeFileSync(
      path.join(process.cwd(), 'data', 'stats.json'),
      JSON.stringify(computeStats(allRecords), null, 2)
    );

    clearCache();

    return NextResponse.json({ success: true, added: newRecords.length, total: allRecords.length, mode });
  } catch (err) {
    console.error('Upload error:', err);
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
