import { NextRequest, NextResponse } from 'next/server';
import { searchBreaches } from '@/lib/dataStore';
import type { SortOption } from '@/types/breach';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const query = searchParams.get('q') || '';
    const category = searchParams.get('category') || '';
    const country = searchParams.get('country') || '';
    const industry = searchParams.get('industry') || '';
    const actor = searchParams.get('actor') || '';
    const region = searchParams.get('region') || '';
    const dateFrom = searchParams.get('dateFrom') || '';
    const dateTo = searchParams.get('dateTo') || '';
    const page = parseInt(searchParams.get('page') || '1', 10);
    const perPage = Math.min(parseInt(searchParams.get('perPage') || '20', 10), 100);
    const sort = (searchParams.get('sort') || 'date-desc') as SortOption;

    const result = searchBreaches(
      { query, category, country, industry, actor, region, dateFrom, dateTo },
      page,
      perPage,
      sort
    );

    return NextResponse.json(result, {
      headers: { 'Cache-Control': 's-maxage=60, stale-while-revalidate=300' },
    });
  } catch (err) {
    console.error('Search error:', err);
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}
