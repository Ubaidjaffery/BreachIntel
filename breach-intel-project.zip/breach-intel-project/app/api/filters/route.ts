import { NextResponse } from 'next/server';
import { getFiltersData, getAutocomplete } from '@/lib/dataStore';
import { NextRequest } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const autocomplete = searchParams.get('autocomplete') || '';

    if (autocomplete) {
      const suggestions = getAutocomplete(autocomplete);
      return NextResponse.json({ suggestions });
    }

    const data = getFiltersData();
    return NextResponse.json(data, {
      headers: { 'Cache-Control': 's-maxage=600, stale-while-revalidate=3600' },
    });
  } catch (err) {
    console.error('Filters error:', err);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
