import { NextRequest, NextResponse } from 'next/server';
import { getAllRecords } from '@/lib/dataStore';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const q = searchParams.get('q')?.toLowerCase() || '';

    const records = getAllRecords();
    const actorMap = new Map<string, { count: number; categories: Set<string>; countries: Set<string> }>();

    for (const r of records) {
      const actor = r['Threat Actor'];
      if (!actor) continue;
      if (!actorMap.has(actor)) {
        actorMap.set(actor, { count: 0, categories: new Set(), countries: new Set() });
      }
      const entry = actorMap.get(actor)!;
      entry.count++;
      if (r.Category) entry.categories.add(r.Category);
      if (r.Country) entry.countries.add(r.Country);
    }

    let actors = Array.from(actorMap.entries())
      .map(([name, data]) => ({
        name,
        count: data.count,
        categories: Array.from(data.categories),
        countries: Array.from(data.countries).slice(0, 5),
      }))
      .sort((a, b) => b.count - a.count);

    if (q) {
      actors = actors.filter((a) => a.name.toLowerCase().includes(q));
    }

    return NextResponse.json({
      actors: actors.slice(0, 100),
      total: actors.length,
    });
  } catch (err) {
    console.error('Threat actors error:', err);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
