import { NextRequest, NextResponse } from 'next/server';
import { getBreachById, searchBreaches } from '@/lib/dataStore';

export const dynamic = 'force-dynamic';

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const record = getBreachById(parseInt(id, 10));
    if (!record) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    // Get related breaches by same actor or country
    const related = searchBreaches(
      { actor: record['Threat Actor'] || '' },
      1,
      6,
      'date-desc'
    );

    return NextResponse.json({
      record,
      related: related.records.filter((r) => r.id !== record.id).slice(0, 5),
    });
  } catch (err) {
    console.error('Breach detail error:', err);
    return NextResponse.json({ error: 'Failed to fetch breach' }, { status: 500 });
  }
}
