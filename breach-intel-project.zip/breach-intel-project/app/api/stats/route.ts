import { NextResponse } from 'next/server';
import path from 'path';
import fs from 'fs';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const filePath = path.join(process.cwd(), 'data', 'stats.json');
    const raw = fs.readFileSync(filePath, 'utf-8');
    const stats = JSON.parse(raw);
    return NextResponse.json(stats, {
      headers: { 'Cache-Control': 's-maxage=300, stale-while-revalidate=600' },
    });
  } catch (err) {
    console.error('Stats error:', err);
    return NextResponse.json({ error: 'Stats failed' }, { status: 500 });
  }
}
