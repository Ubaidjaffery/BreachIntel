'use client';
import { MapPin, Calendar, User, Globe, Tag } from 'lucide-react';
import type { BreachRecord } from '@/types/breach';
import { getCategoryBadgeClass, getSeverity, timeAgo, formatDate } from '@/lib/utils';

interface Props {
  record: BreachRecord;
  onClick: (record: BreachRecord) => void;
}

export default function BreachCard({ record, onClick }: Props) {
  const badgeCls = getCategoryBadgeClass(record.Category);
  const sev = getSeverity(record.Category);
  const victim = record['Victim Name'] || 'Unknown Victim';
  const domain = record['Victim Domain'] || '';
  const actor = record['Threat Actor'] || 'Unknown';

  return (
    <div className="breach-card" onClick={() => onClick(record)} style={{ padding: '14px 16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, marginBottom: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text-primary)', marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {victim}
          </div>
          {domain && (
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: '#e5395c', opacity: 0.85, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {domain}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5, flexShrink: 0 }}>
          <span className={badgeCls} style={{ fontSize: 11, padding: '2px 9px', borderRadius: 4, fontWeight: 600, letterSpacing: '0.3px' }}>
            {record.Category}
          </span>
          <span className={sev.cls} style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, fontWeight: 600 }}>
            {sev.label}
          </span>
        </div>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, fontSize: 12, color: 'var(--text-secondary)' }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <User size={11} color="#e5395c" />
          <span style={{ color: 'var(--text-primary)', fontWeight: 500, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{actor}</span>
        </span>
        {record.Country && (
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <MapPin size={11} />
            {record.Country.length > 25 ? record.Country.slice(0, 25) + '…' : record.Country}
          </span>
        )}
        {record.Industry && (
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <Tag size={11} />
            {record.Industry.length > 28 ? record.Industry.slice(0, 28) + '…' : record.Industry}
          </span>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--border)' }}>
        <Calendar size={11} style={{ color: 'var(--text-tertiary)' }} />
        <span style={{ fontSize: 11, color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
          {formatDate(record.breach_date_iso)}
        </span>
        <span style={{ fontSize: 11, color: 'var(--text-tertiary)', marginLeft: 'auto' }}>
          {timeAgo(record.breach_date_iso)}
        </span>
        {record.Region && (
          <span style={{ fontSize: 11, color: 'var(--text-tertiary)', display: 'flex', alignItems: 'center', gap: 3 }}>
            <Globe size={10} />
            {record.Region}
          </span>
        )}
      </div>
    </div>
  );
}
