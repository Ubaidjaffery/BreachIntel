'use client';
import { useEffect, useState } from 'react';
import { X, ExternalLink, User, MapPin, Tag, Calendar, Globe, Shield, AlertTriangle, ChevronRight } from 'lucide-react';
import type { BreachRecord } from '@/types/breach';
import { getCategoryBadgeClass, getSeverity, formatDate } from '@/lib/utils';
import BreachCard from './BreachCard';

interface Props {
  record: BreachRecord;
  onClose: () => void;
  onRelatedClick: (record: BreachRecord) => void;
}

export default function BreachModal({ record, onClose, onRelatedClick }: Props) {
  const [related, setRelated] = useState<BreachRecord[]>([]);
  const badgeCls = getCategoryBadgeClass(record.Category);
  const sev = getSeverity(record.Category);

  useEffect(() => {
    fetch(`/api/breach/${record.id}`)
      .then((r) => r.json())
      .then((d) => setRelated(d.related || []))
      .catch(() => {});
  }, [record.id]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  const victim = record['Victim Name'] || 'Unknown Victim';
  const domain = record['Victim Domain'] || '';
  const actor = record['Threat Actor'] || 'Unknown Actor';

  return (
    <div
      className="modal-backdrop"
      style={{ position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'flex-start', justifyContent: 'center', padding: '20px 16px', overflowY: 'auto' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        style={{ background: 'var(--bg-card)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, width: '100%', maxWidth: 640, marginTop: 20 }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ padding: '20px 20px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <h2 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4, lineHeight: 1.2 }}>{victim}</h2>
              {domain && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: '#e5395c' }}>{domain}</span>
                  <a href={`https://${domain}`} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--text-tertiary)' }}><ExternalLink size={11} /></a>
                </div>
              )}
            </div>
            <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border)', borderRadius: 6, width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--text-secondary)', flexShrink: 0 }}>
              <X size={16} />
            </button>
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
            <span className={badgeCls} style={{ fontSize: 11, padding: '3px 10px', borderRadius: 4, fontWeight: 600 }}>{record.Category}</span>
            <span className={sev.cls} style={{ fontSize: 11, padding: '3px 10px', borderRadius: 4, fontWeight: 600 }}>{sev.label} Severity</span>
            <span style={{ fontSize: 11, padding: '3px 10px', borderRadius: 4, fontWeight: 500, background: 'rgba(255,255,255,0.05)', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>
              {formatDate(record.breach_date_iso)}
            </span>
          </div>
        </div>

        {/* Body */}
        <div style={{ padding: 20 }}>
          {/* Key details grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
            {[
              { label: 'Threat Actor', value: actor, icon: <User size={13} color="#e5395c" />, highlight: true },
              { label: 'Country', value: record.Country || '—', icon: <MapPin size={13} /> },
              { label: 'Region', value: record.Region || '—', icon: <Globe size={13} /> },
              { label: 'Industry', value: record.Industry || '—', icon: <Tag size={13} /> },
            ].map(({ label, value, icon, highlight }) => (
              <div key={label} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
                  <span style={{ color: 'var(--text-tertiary)' }}>{icon}</span>
                  <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.7px' }}>{label}</span>
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: highlight ? '#e5395c' : 'var(--text-primary)' }}>
                  {value.length > 35 ? value.slice(0, 35) + '…' : value}
                </div>
              </div>
            ))}
          </div>

          {/* Breach date full */}
          <div style={{ background: 'rgba(229,57,92,0.05)', border: '1px solid rgba(229,57,92,0.15)', borderRadius: 8, padding: '12px 14px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
            <Calendar size={16} color="#e5395c" />
            <div>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', color: 'var(--text-secondary)', marginBottom: 2 }}>Breach Reported</div>
              <div style={{ fontSize: 13, fontFamily: 'var(--font-mono)', color: 'var(--text-primary)' }}>{record['Breach Date']}</div>
            </div>
          </div>

          {/* Intel note */}
          <div style={{ background: 'rgba(59,130,246,0.05)', border: '1px solid rgba(59,130,246,0.15)', borderRadius: 8, padding: '12px 14px', marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <Shield size={13} color="#3b82f6" />
              <span style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', color: '#3b82f6' }}>Intelligence Note</span>
            </div>
            <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
              This incident was claimed by <strong style={{ color: 'var(--text-primary)' }}>{actor}</strong> and categorized as a <strong style={{ color: 'var(--text-primary)' }}>{record.Category}</strong> attack targeting{record.Industry ? ` the ${record.Industry} sector` : ' the organization'}{record.Country ? ` in ${record.Country}` : ''}.{' '}
              {record.Category === 'Ransomware' && 'Ransomware attacks typically involve data exfiltration prior to encryption and double-extortion demands.'}
              {record.Category === 'DDoS' && 'DDoS campaigns may be hacktivist-motivated or used as a distraction for secondary intrusion attempts.'}
              {record.Category === 'Leaks' && 'Data leaks may expose sensitive PII, credentials, or proprietary information on dark web forums.'}
              {record.Category === 'Selling of data' && 'Stolen datasets are commonly listed on underground markets and Telegram channels for monetization.'}
              {record.Category === 'Defacement' && 'Website defacement can indicate deeper server compromise; full forensic investigation is recommended.'}
            </p>
          </div>

          {/* Recommendations */}
          <div style={{ background: 'rgba(34,197,94,0.05)', border: '1px solid rgba(34,197,94,0.15)', borderRadius: 8, padding: '12px 14px', marginBottom: related.length ? 20 : 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <AlertTriangle size={13} color="#22c55e" />
              <span style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', color: '#22c55e' }}>Recommended Actions</span>
            </div>
            <ul style={{ margin: 0, paddingLeft: 16 }}>
              {[
                'Monitor threat actor channels for data publication',
                'Enforce MFA across all external-facing services',
                'Review and patch known CVEs in your attack surface',
                'Enable dark web exposure monitoring',
                'Conduct tabletop incident response exercises',
              ].map((item) => (
                <li key={item} style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.8 }}>{item}</li>
              ))}
            </ul>
          </div>

          {/* Related breaches */}
          {related.length > 0 && (
            <div style={{ marginTop: 20 }}>
              <div style={{ fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', color: 'var(--text-secondary)', marginBottom: 10 }}>
                Other incidents by {actor}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {related.slice(0, 3).map((r) => (
                  <div
                    key={r.id}
                    onClick={() => onRelatedClick(r)}
                    style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 6, border: '1px solid var(--border)', cursor: 'pointer' }}
                    onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'rgba(229,57,92,0.3)')}
                    onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
                  >
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r['Victim Name'] || 'Unknown'}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{r.Country} · {formatDate(r.breach_date_iso)}</div>
                    </div>
                    <ChevronRight size={14} color="var(--text-tertiary)" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '0 20px 20px', display: 'flex', gap: 10 }}>
          <button
            className="btn-accent"
            style={{ flex: 1, height: 40, fontSize: 13 }}
            onClick={() => { window.location.href = `/search?actor=${encodeURIComponent(actor)}`; }}
          >
            View all {actor} attacks →
          </button>
          <button
            onClick={onClose}
            style={{ height: 40, padding: '0 16px', background: 'transparent', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text-secondary)', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font-display)' }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
