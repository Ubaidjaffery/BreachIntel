export interface BreachRecord {
  id: number;
  Category: string;
  'Breach Date': string;
  'Victim Name': string;
  'Victim Domain': string;
  'Threat Actor': string;
  Country: string;
  Region: string;
  Industry: string;
  source: string;
  breach_date_iso: string;
}

export interface SearchFilters {
  query: string;
  category: string;
  country: string;
  industry: string;
  actor: string;
  region: string;
  dateFrom: string;
  dateTo: string;
}

export interface SearchResult {
  records: BreachRecord[];
  total: number;
  page: number;
  perPage: number;
  totalPages: number;
}

export interface StatsData {
  total: number;
  categories: Record<string, number>;
  topIndustries: Record<string, number>;
  topActors: Record<string, number>;
  topCountries: Record<string, number>;
  topRegions: Record<string, number>;
  monthly: Record<string, number>;
}

export type SortOption = 'date-desc' | 'date-asc' | 'victim' | 'actor' | 'country';
