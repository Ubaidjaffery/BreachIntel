import path from 'path';
import fs from 'fs';
import Fuse from 'fuse.js';
import type { BreachRecord, SearchFilters, SearchResult, SortOption } from '@/types/breach';

const COUNTRY_ALIASES: Record<string, string> = {
  'United States': 'United States of America',
  'United Kingdom': 'United Kingdom of Great Britain and Northern Ireland',
};

function normalizeCountry(name: string): string {
  const trimmed = name.trim();
  return COUNTRY_ALIASES[trimmed] || trimmed;
}

function parseCountries(raw: string | undefined): string[] {
  if (!raw) return [];
  return raw.split(',').map(normalizeCountry).filter(Boolean);
}

function parseIndustries(raw: string | undefined): string[] {
  if (!raw) return [];
  return raw.split(',').map((s) => s.trim()).filter(Boolean);
}

let _records: BreachRecord[] | null = null;
let _fuse: Fuse<BreachRecord> | null = null;

function loadData(): BreachRecord[] {
  if (_records) return _records;
  const filePath = path.join(process.cwd(), 'data', 'tac_data.json');
  const raw = fs.readFileSync(filePath, 'utf-8');
  _records = JSON.parse(raw) as BreachRecord[];
  return _records;
}

function getFuse(): Fuse<BreachRecord> {
  if (_fuse) return _fuse;
  const records = loadData();
  _fuse = new Fuse(records, {
    keys: [
      { name: 'Victim Name', weight: 0.35 },
      { name: 'Victim Domain', weight: 0.3 },
      { name: 'Threat Actor', weight: 0.2 },
      { name: 'Country', weight: 0.08 },
      { name: 'Industry', weight: 0.07 },
    ],
    threshold: 0.35,
    includeScore: true,
    minMatchCharLength: 2,
    ignoreLocation: true,
  });
  return _fuse;
}

export function clearCache(): void {
  _records = null;
  _fuse = null;
}

export function getAllRecords(): BreachRecord[] {
  return loadData();
}

export function searchBreaches(
  filters: Partial<SearchFilters>,
  page = 1,
  perPage = 20,
  sort: SortOption = 'date-desc'
): SearchResult {
  const records = loadData();
  const { query, category, country, industry, actor, region, dateFrom, dateTo } = filters;

  let results: BreachRecord[];

  if (query && query.trim().length >= 2) {
    const fuse = getFuse();
    const fuseResults = fuse.search(query.trim());
    results = fuseResults.map((r) => r.item);
  } else {
    results = [...records];
  }

  // Apply filters
  if (category) results = results.filter((r) => r.Category === category);
  if (country) {
    const norm = normalizeCountry(country);
    results = results.filter((r) => parseCountries(r.Country).includes(norm));
  }
  if (industry) results = results.filter((r) => parseIndustries(r.Industry).includes(industry));
  if (actor) results = results.filter((r) => r['Threat Actor'] === actor);
  if (region) results = results.filter((r) => r.Region === region);
  if (dateFrom) {
    const from = new Date(dateFrom);
    results = results.filter((r) => new Date(r.breach_date_iso) >= from);
  }
  if (dateTo) {
    const to = new Date(dateTo);
    results = results.filter((r) => new Date(r.breach_date_iso) <= to);
  }

  // Sort
  results.sort((a, b) => {
    switch (sort) {
      case 'date-desc':
        return new Date(b.breach_date_iso).getTime() - new Date(a.breach_date_iso).getTime();
      case 'date-asc':
        return new Date(a.breach_date_iso).getTime() - new Date(b.breach_date_iso).getTime();
      case 'victim':
        return (a['Victim Name'] || '').localeCompare(b['Victim Name'] || '');
      case 'actor':
        return (a['Threat Actor'] || '').localeCompare(b['Threat Actor'] || '');
      case 'country':
        return (a.Country || '').localeCompare(b.Country || '');
      default:
        return 0;
    }
  });

  const total = results.length;
  const totalPages = Math.ceil(total / perPage);
  const start = (page - 1) * perPage;
  const pageRecords = results.slice(start, start + perPage);

  return { records: pageRecords, total, page, perPage, totalPages };
}

export function getBreachById(id: number): BreachRecord | undefined {
  const records = loadData();
  return records.find((r) => r.id === id);
}

export function getAutocomplete(query: string): string[] {
  if (!query || query.length < 2) return [];
  const records = loadData();
  const q = query.toLowerCase();
  const seen = new Set<string>();
  const results: string[] = [];

  for (const r of records) {
    if (results.length >= 8) break;
    const fields = [r['Victim Name'], r['Victim Domain'], r['Threat Actor']];
    for (const f of fields) {
      if (f && f.toLowerCase().includes(q) && !seen.has(f)) {
        seen.add(f);
        results.push(f);
      }
    }
  }
  return results.slice(0, 8);
}

export function getFiltersData() {
  const records = loadData();
  const categories = [...new Set(records.map((r) => r.Category).filter(Boolean))].sort();
  const countries = [...new Set(records.flatMap((r) => parseCountries(r.Country)))].sort();
  const industries = [...new Set(records.flatMap((r) => parseIndustries(r.Industry)))].sort();
  const actors = [...new Set(records.map((r) => r['Threat Actor']).filter(Boolean))].sort();
  const regions = [...new Set(records.map((r) => r.Region).filter(Boolean))].sort();
  return { categories, countries, industries, actors, regions };
}
