export function getCategoryBadgeClass(category: string): string {
  const map: Record<string, string> = {
    Ransomware: 'badge-ransomware',
    DDoS: 'badge-ddos',
    Leaks: 'badge-leaks',
    'Selling of data': 'badge-selling',
    Defacement: 'badge-defacement',
    'Underground chatter': 'badge-underground',
    'Cyber Attack': 'badge-cyber',
  };
  return map[category] || 'badge-unknown';
}

export function getSeverity(category: string): { label: string; cls: string } {
  const map: Record<string, { label: string; cls: string }> = {
    Ransomware: { label: 'Critical', cls: 'sev-critical' },
    Leaks: { label: 'High', cls: 'sev-high' },
    'Selling of data': { label: 'High', cls: 'sev-high' },
    DDoS: { label: 'Medium', cls: 'sev-medium' },
    Defacement: { label: 'Medium', cls: 'sev-medium' },
    'Underground chatter': { label: 'Low', cls: 'sev-low' },
    'Cyber Attack': { label: 'High', cls: 'sev-high' },
  };
  return map[category] || { label: 'Unknown', cls: 'sev-low' };
}

export function formatDate(iso: string): string {
  if (!iso) return 'Unknown';
  try {
    const d = new Date(iso);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return iso;
  }
}

export function timeAgo(iso: string): string {
  if (!iso) return '';
  try {
    const diff = Date.now() - new Date(iso).getTime();
    const days = Math.floor(diff / 86400000);
    if (days < 1) return 'Today';
    if (days < 7) return `${days}d ago`;
    if (days < 30) return `${Math.floor(days / 7)}w ago`;
    if (days < 365) return `${Math.floor(days / 30)}mo ago`;
    return `${Math.floor(days / 365)}y ago`;
  } catch {
    return '';
  }
}

export function truncate(str: string, max: number): string {
  if (!str) return '';
  return str.length > max ? str.slice(0, max) + '…' : str;
}

export function buildSearchUrl(params: Record<string, string>): string {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => { if (v) qs.set(k, v); });
  return `/search?${qs.toString()}`;
}

export function getCategoryColor(category: string): string {
  const map: Record<string, string> = {
    Ransomware: '#ef4444',
    DDoS: '#3b82f6',
    Leaks: '#f59e0b',
    'Selling of data': '#22c55e',
    Defacement: '#a855f7',
    'Underground chatter': '#14b8a6',
    'Cyber Attack': '#f97316',
  };
  return map[category] || '#6b7280';
}
