# BreachIntel — Windows Server Deployment Guide

## Table of Contents

1. [System Requirements](#1-system-requirements)
2. [Install Prerequisites](#2-install-prerequisites)
3. [Deploy the Application](#3-deploy-the-application)
4. [Configure Environment Variables](#4-configure-environment-variables)
5. [Build the Application](#5-build-the-application)
6. [Run with PM2 Process Manager](#6-run-with-pm2-process-manager)
7. [Set Up IIS Reverse Proxy](#7-set-up-iis-reverse-proxy)
8. [Configure Windows Firewall](#8-configure-windows-firewall)
9. [HTTPS / SSL Certificate (Optional)](#9-https--ssl-certificate-optional)
10. [Updating the Application](#10-updating-the-application)
11. [Troubleshooting](#11-troubleshooting)
12. [Deployment Checklist](#12-deployment-checklist)

---

## 1. System Requirements

| Component | Minimum |
|-----------|---------|
| OS | Windows Server 2016 / 2019 / 2022 |
| RAM | 2 GB |
| Disk | 5 GB free |
| Node.js | v20.0.0 or higher |
| IIS | 10.0 or higher |

---

## 2. Install Prerequisites

### 2.1 Node.js

1. Download the Windows installer from **https://nodejs.org** (choose the LTS version, v20+)
2. Run the installer and follow the prompts — keep all default options
3. Verify the installation by opening PowerShell and running:
   ```powershell
   node --version
   npm --version
   ```
   Both commands should return a version number.

### 2.2 PM2 (Process Manager)

PM2 keeps the application running in the background and automatically restarts it after crashes or server reboots.

Open PowerShell **as Administrator** and run:

```powershell
npm install -g pm2
npm install -g pm2-windows-startup
```

### 2.3 Git (Optional)

Only required if you are pulling the code from a Git repository.

Download from **https://git-scm.com** and install with default options.

---

## 3. Deploy the Application

### Option A — Copy files manually

1. Compress the project folder into a ZIP (exclude the `node_modules` folder)
2. Transfer the ZIP to the server via RDP, shared drive, or file transfer tool
3. Extract to `C:\apps\breach-intel`

### Option B — Clone from Git repository

Open PowerShell and run:

```powershell
cd C:\apps
git clone <your-repository-url> breach-intel
```

### Important — Data Files

Make sure the following files are present on the server after copying. These are the live database files and are typically not included in Git repositories:

```
C:\apps\breach-intel\data\tac_data.json
C:\apps\breach-intel\data\stats.json
```

Copy these manually from your local machine to the server if they are not included in the repository.

---

## 4. Configure Environment Variables

In the project root (`C:\apps\breach-intel`), create a file named `.env.local` with the following content:

```
UPLOAD_PASSWORD=your-secret-password
```

Replace `your-secret-password` with a strong password of your choice. This password protects the `/upload` admin page.

> **Note:** Never commit `.env.local` to version control.

---

## 5. Build the Application

Open PowerShell in the project folder and run:

```powershell
cd C:\apps\breach-intel
npm install
npm run build
```

- `npm install` downloads all dependencies into the `node_modules` folder
- `npm run build` compiles the Next.js application for production

The build process may take 1–3 minutes. A successful build ends with output similar to:

```
Route (app)                   Size
┌ ○ /                         ...
├ ○ /search                   ...
├ ○ /dashboard                ...
└ ○ /upload                   ...
```

---

## 6. Run with PM2 Process Manager

### 6.1 Start the application

```powershell
cd C:\apps\breach-intel
pm2 start npm --name "breach-intel" -- start
```

### 6.2 Save the process list

```powershell
pm2 save
```

### 6.3 Enable auto-start on reboot

```powershell
pm2-startup install
```

### 6.4 Verify the application is running

```powershell
pm2 status
```

You should see `breach-intel` with status `online`.

Open a browser on the server and navigate to **http://localhost:3000** to confirm the app loads.

### Useful PM2 Commands

| Command | Description |
|---------|-------------|
| `pm2 status` | Show all running processes |
| `pm2 logs breach-intel` | View live application logs |
| `pm2 restart breach-intel` | Restart the application |
| `pm2 stop breach-intel` | Stop the application |
| `pm2 delete breach-intel` | Remove from PM2 |

---

## 7. Set Up IIS Reverse Proxy

IIS will receive requests on port 80 (and 443 for HTTPS) and forward them to the Node.js app running on port 3000.

### 7.1 Install IIS

1. Open **Server Manager**
2. Click **Manage → Add Roles and Features**
3. Select **Web Server (IIS)** and complete the wizard

### 7.2 Install Required IIS Modules

Download and install both modules:

- **URL Rewrite** — https://www.iis.net/downloads/microsoft/url-rewrite
- **Application Request Routing (ARR)** — https://www.iis.net/downloads/microsoft/application-request-routing

Run both installers, then restart IIS:

```powershell
iisreset
```

### 7.3 Enable the Proxy in ARR

1. Open **IIS Manager** (search for it in the Start menu)
2. Click on the **server name** in the left panel (not a site)
3. Double-click **Application Request Routing Cache**
4. In the right panel, click **Server Proxy Settings**
5. Check **Enable proxy**
6. Click **Apply**

### 7.4 Create the Reverse Proxy Rule

1. In IIS Manager, expand **Sites** and click on **Default Web Site** (or create a new site)
2. Double-click **URL Rewrite**
3. Click **Add Rule(s)** in the right panel
4. Select **Reverse Proxy** and click **OK**
5. In the **Inbound Rules** field enter:
   ```
   localhost:3000
   ```
6. Click **OK**

The application is now accessible at **http://your-server-ip** or **http://your-domain.com**.

---

## 8. Configure Windows Firewall

Allow inbound traffic on port 80 (and 443 if using HTTPS).

Open PowerShell **as Administrator**:

```powershell
# Allow HTTP
netsh advfirewall firewall add rule name="BreachIntel HTTP" dir=in action=allow protocol=TCP localport=80

# Allow HTTPS (if using SSL)
netsh advfirewall firewall add rule name="BreachIntel HTTPS" dir=in action=allow protocol=TCP localport=443
```

---

## 9. HTTPS / SSL Certificate (Optional)

### Using win-acme (Let's Encrypt — Free)

> Requires a domain name pointed to your server's public IP.

1. Download **win-acme** from https://www.win-acme.com
2. Extract and run `wacs.exe` as Administrator
3. Choose **Create certificate (default settings)**
4. Select **IIS** and pick your site
5. win-acme will obtain a certificate and configure IIS automatically
6. Certificates auto-renew — no manual action needed

### Using a Purchased Certificate

1. In IIS Manager, click the server name → **Server Certificates**
2. Click **Import** in the right panel
3. Browse to your `.pfx` certificate file and enter the password
4. Go to your site → **Bindings** → **Add**
5. Type: `https`, Port: `443`, select your certificate
6. Click **OK**

---

## 10. Updating the Application

When you have new code or data to deploy:

### Update code

```powershell
cd C:\apps\breach-intel

# If using Git
git pull

# Reinstall dependencies (if package.json changed)
npm install

# Rebuild
npm run build

# Restart the app
pm2 restart breach-intel
```

### Update data only (without code changes)

You can upload new data directly through the app's **Import** page (`/upload`) without any command-line steps — no restart required.

Alternatively, replace `data/tac_data.json` and `data/stats.json` manually, then restart:

```powershell
pm2 restart breach-intel
```

---

## 11. Troubleshooting

### App not starting

```powershell
pm2 logs breach-intel --lines 50
```

Check for missing `.env.local`, failed build, or port conflicts.

### Port 3000 already in use

```powershell
netstat -ano | findstr :3000
```

Note the PID in the last column, then:

```powershell
taskkill /PID <pid> /F
```

### IIS shows 502 Bad Gateway

- Confirm the Node.js app is running: `pm2 status`
- Confirm ARR proxy is enabled (Step 7.3)
- Confirm the URL Rewrite rule points to `localhost:3000`

### Data not updating after upload

The app caches data in memory. A restart forces a fresh load:

```powershell
pm2 restart breach-intel
```

### Check application logs

```powershell
pm2 logs breach-intel
```

Log files are also stored at:
```
C:\Users\<your-user>\.pm2\logs\breach-intel-out.log
C:\Users\<your-user>\.pm2\logs\breach-intel-error.log
```

---

## 12. Deployment Checklist

| Step | Description | Done |
|------|-------------|------|
| 1 | Node.js v20+ installed and verified | ☐ |
| 2 | PM2 and pm2-windows-startup installed globally | ☐ |
| 3 | Project files copied to `C:\apps\breach-intel` | ☐ |
| 4 | `data/tac_data.json` and `data/stats.json` present | ☐ |
| 5 | `.env.local` created with `UPLOAD_PASSWORD` | ☐ |
| 6 | `npm install` completed successfully | ☐ |
| 7 | `npm run build` completed successfully | ☐ |
| 8 | PM2 started, saved, and startup configured | ☐ |
| 9 | App accessible at `http://localhost:3000` | ☐ |
| 10 | IIS installed with URL Rewrite and ARR modules | ☐ |
| 11 | ARR proxy enabled | ☐ |
| 12 | URL Rewrite reverse proxy rule created | ☐ |
| 13 | Firewall port 80 (and 443) opened | ☐ |
| 14 | App accessible from external browser | ☐ |
| 15 | SSL certificate installed (if using HTTPS) | ☐ |

---

*Document generated for BreachIntel v0.1.0*
