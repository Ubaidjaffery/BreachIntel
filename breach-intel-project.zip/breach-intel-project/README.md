# BreachIntel — Cyber Threat Intelligence Platform

A production-ready Next.js 15 application for searching and exploring 50,000+ cyber breach records.

## Features

- **Global Search** — fuzzy search across victim names, domains, threat actors, countries, and industries
- **50,000 records** from the THREAT_ACTOR_CLAIMS dataset, enriched with attack patterns from Master Data
- **Real-time filters** — category, country, industry, threat actor, region, date range
- **Analytics Dashboard** — charts for category distribution, monthly trends, top actors, industries, countries
- **Threat Actors Directory** — browse all 450+ tracked threat actors with incident counts
- **Breach Detail Modal** — full intelligence notes, remediation guidance, related incidents
- **Autocomplete** — instant suggestions as you type
- **Dark mode** — cybersecurity-themed dark UI using Syne + Space Mono fonts

## Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Set up data files

The data files are already included in `/data/`:
- `data/tac_data.json` — 50,000 breach records (generated from THREAT_ACTOR_CLAIMS xlsx)
- `data/stats.json` — precomputed statistics

To regenerate from the Excel files:

```bash
python3 scripts/process_data.py
```

### 3. Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

### 4. Build for production

```bash
npm run build
npm start
```

## Project Structure

```
breach-intel/
├── app/
│   ├── page.tsx              # Landing page with hero search
│   ├── search/page.tsx       # Search results with filters
│   ├── dashboard/page.tsx    # Analytics dashboard
│   ├── threat-actors/page.tsx # Threat actor directory
│   ├── api/
│   │   ├── search/route.ts   # GET /api/search
│   │   ├── stats/route.ts    # GET /api/stats
│   │   ├── breach/[id]/route.ts  # GET /api/breach/:id
│   │   ├── threat-actors/route.ts # GET /api/threat-actors
│   │   └── filters/route.ts  # GET /api/filters
│   ├── globals.css
│   └── layout.tsx
├── components/
│   ├── Navbar.tsx
│   ├── BreachCard.tsx
│   └── BreachModal.tsx
├── lib/
│   ├── dataStore.ts          # Data loading + search logic (Fuse.js)
│   └── utils.ts              # Utility functions
├── types/
│   └── breach.ts             # TypeScript interfaces
├── data/
│   ├── tac_data.json         # 50K breach records
│   └── stats.json            # Precomputed stats
└── scripts/
    └── process_data.py       # Excel → JSON pipeline
```

## API Reference

### `GET /api/search`

| Param | Type | Description |
|-------|------|-------------|
| `q` | string | Full-text search query |
| `category` | string | Filter by attack category |
| `country` | string | Filter by country |
| `industry` | string | Filter by industry |
| `actor` | string | Filter by threat actor |
| `region` | string | Filter by region |
| `sort` | string | `date-desc` \| `date-asc` \| `victim` \| `actor` \| `country` |
| `page` | number | Page number (default: 1) |
| `perPage` | number | Results per page (max: 100) |

### `GET /api/stats`

Returns aggregated statistics: category counts, top actors/industries/countries/regions, monthly breakdown.

### `GET /api/breach/:id`

Returns a single breach record plus related breaches by the same threat actor.

### `GET /api/threat-actors`

Returns all unique threat actors with incident counts, categories, and countries.

### `GET /api/filters`

Returns available filter options. Supports `?autocomplete=<query>` for search suggestions.

## Data Pipeline

Run `scripts/process_data.py` to re-process Excel files:

```bash
pip install pandas openpyxl
python3 scripts/process_data.py
```

This reads:
- `THREAT_ACTOR_CLAIMS06052026.xlsx` — primary dataset (50,000 records)
- `Master_Data.xlsx` — enrichment data (attack patterns, CVEs, remediation)

## Environment Variables

No API keys required. All data is served from local JSON files.

```env
# Optional
NODE_ENV=production
```

## Deployment

### Vercel

```bash
npx vercel
```

Note: The 14MB data file requires the `maxLambdaSize` to be increased or the data to be served from a CDN/database for production scale.

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm ci && npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## Performance Notes

- Data is loaded once at startup and cached in memory
- Fuse.js provides fuzzy search across 50K records in ~50ms
- Stats are precomputed and served from a static JSON file
- For >100K records, consider migrating to SQLite with better-sqlite3

## Tech Stack

- **Next.js 15** + React 18 + TypeScript
- **Fuse.js** — fuzzy search
- **Chart.js** — analytics charts  
- **Lucide React** — icons
- **Syne** + **Space Mono** — typography
